<?php
/* Notes:
- “GET Demo” shows query strings & URL encoding from index.php.
- “Newsletter (PRG)” is the form page with sticky fields, validation, PRG flash.
*/
?>
<nav class="navbar bg-light mb-3">
    <div class="container">
        <a class="navbar-brand" href="index.php">Home</a>
        <a class="nav-link" href="index.php?report=available">Available</a>
        <a class="nav-link" href="index.php?report=top3">Top 3 Bikes</a>
        <a class="nav-link" href="index.php?report=open">Open rentals</a>
        <a class="nav-link" href="index.php?report=multi">Rentals, Customers, and Bikes</a>
        <a class="nav-link" href="index.php?report=customers">Customers</a>
        <a class="nav-link" href="index.php?report=completed">Completed Rentals</a>



    </div>
</nav>