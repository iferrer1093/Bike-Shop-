<?php 
function sqlAvailableBikes(): string
{
    return "SELECT * FROM bikes WHERE available = 1;";
}
?>