<?php
function sqlMultiJoinRentals(): string 
{
    return 
    "SELECT rentals.rental_id, customers.first_name, customers.last_name,
    bikes.model, bikes.type, rentals.start_time, rentals.end_time
    FROM rentals
    INNER JOIN customers ON rentals.customer_id = customers.customer_id
    INNER JOIN bikes ON rentals.bike_id = bikes.bike_id;";
}
?>