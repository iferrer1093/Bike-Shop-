<?php 
function sqlTop3Bikes(): string 
{
    return "SELECT * FROM bikes ORDER BY hourly_rate DESC LIMIT 3;";
}
?>