<?php 
function sqlOpenRentals(): string 
{
    return "SELECT * FROM rentals WHERE end_time IS NOT NULL;";
}
?>