<?php
    // Database stuff from the db.php page.
        $DB_HOST = 'localhost';
        $DB_NAME = 'bikes';
        $DB_USER = 'root';
        $DB_PASS = '';
    $pdo = db();
    function db()
    {
        global 
        $DB_HOST,
        $DB_NAME,
        $DB_USER,
        $DB_PASS;

        $dsn="mysql:host=$DB_HOST; dbname=$DB_NAME";

        

    try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS);
    return $pdo;
    } catch (PDOException $e) 
    {
    echo "Database connection failed: " . $e->getMessage();
    exit;
    }
    }


    // All of the functions from the functions.php page.
function sqlAllCustomers(): string
{
    return "SELECT * FROM customers ORDER BY last_name, first_name;";
}

function sqlAvailableBikes(): string
{
    return "SELECT * FROM bikes WHERE available = 1;";
}

function sqlAllBikesByPrice(): string 
{
    return "SELECT * FROM bikes ORDER BY hourly_rate DESC;";
}

function sqlOpenRentals(): string 
{
    return "SELECT * FROM rentals WHERE end_time IS NULL;";
}

function sqlJoinRentalsCustomers(): string 
{
    return 
    "SELECT rentals.*, customers.first_name, customers.last_name
    FROM rentals
    INNER JOIN customers ON rentals.customer_id = customers.customer_id;";
}

function sqlJoinRentalsBikes(): string 
{
    return 
    "SELECT rentals.*, bikes.model, bikes.type, bikes.hourly_rate
    FROM rentals
    INNER JOIN bikes ON rentals.bike_id = bikes.bike_id;";
}

function sqlTop3Bikes(): string 
{
    return "SELECT * FROM bikes ORDER BY hourly_rate DESC LIMIT 3;";
}

function sqlMultiJoinRentals(): string 
{
    return 
    "SELECT rentals.rental_id, customers.first_name, customers.last_name,
    bikes.model, bikes.type, rentals.start_time, rentals.end_time
    FROM rentals
    INNER JOIN customers ON rentals.customer_id = customers.customer_id
    INNER JOIN bikes ON rentals.bike_id = bikes.bike_id;";
}

function sqlUpdateCloseRental(): string 
{
    return "UPDATE rentals SET end_time = NOW() WHERE rental_id = 3;";
}

function sqlUpdateBikeUnavailable(): string 
{
    return "UPDATE bikes SET available = 0 WHERE bike_id = 4;";
}

// $queries = [
//     'All Customers' => 'sqlAllCustomers',
//     'Available Bikes' => 'sqlAvailableBikes',
//     'All Bikes by Price' => 'sqlAllBikesByPrice',
//     'Open Rentals' => 'sqlOpenRentals',
//     'Rentals with Customers' => 'sqlJoinRentalsCustomers',
//     'Rentals with Bikes' => 'sqlJoinRentalsBikes',
//     'Top 3 Most Expensive Bikes' => 'sqlTop3Bikes',
//     'Rentals with Customers & Bikes' => 'sqlMultiJoinRentals',
//     'Close Rental 3' => 'sqlUpdateCloseRental',
//     'Set Bike 4 Unavailable' => 'sqlUpdateBikeUnavailable'
// ];

// You'd want to change this since it's not really a list and I'm also not wanting to display everything on one page like in the bike-rentals.php. Fix that so it only has one display or make sure to change the whole thing for the queries variable. 

// $allCustomers = [
//     'All Customers' => 'sqlAllCustomers'
// ];



?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php require __DIR__ . '/includes/bootstrapcdnlinks.php'; ?>

</head>
<body>
    <?php require __DIR__ . '/includes/navigation.php'; ?>
    <?php
foreach ($queries as $title => $functionName) {
    // Would need to change this to account for the different names and tables and all of that. Pretty awesome. 
    echo "<h2>$title</h2>";

    $sql = $functionName();

    if (stripos($sql, 'SELECT') === 0) {
        $stmt = $pdo->query($sql);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // displayTable($rows); Change this to reference that whole table thing for each individual report. So make some variable and have it grab whatever tables have been made from the different reports. Pretty simple hopefully. 
    } else {
        $pdo->exec($sql);}
    }
        ?>
</body>
</html>